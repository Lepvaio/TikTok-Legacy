# TikTok Legacy 0.1 — ARMv6-first starter

This is a starter Android project, not a finished APK.

## Target
- Android 2.3.3+ (API 10)
- Galaxy Y GT-S5360 is the first test device
- Pure Java: no native `.so` library is included
- Portrait UI, small native widgets, Android `VideoView`/`MediaPlayer`

## Important limitation
TikTok does not provide a general official API that turns arbitrary public TikTok share links into direct MP4 streams. TikTok oEmbed returns embed metadata, not a guaranteed MediaPlayer-compatible MP4 URL. This prototype therefore expects a catalog of direct video URLs that you are authorized to use. Do not assume a TikTok share URL can be passed to `VideoView`.

## Catalog format
Host a JSON file and set `Catalog.CATALOG_URL` in:
`app/src/main/java/com/legacy/tiktok/Catalog.java`

Example:
```json
[
  {
    "title": "Example video",
    "url": "https://your-domain.example/video.mp4"
  }
]
```
The stream must be reachable by the device and encoded in a format/codecs supported by Android 2.3. Prefer H.264 Baseline video with AAC audio in an MP4 container, and test on the actual Galaxy Y.

## Build notes
- Requires Android SDK Platform 35 and a JDK supported by Android Gradle Plugin 8.2.2.
- Build with Gradle 8.2 and run `assembleDebug`.
- `minSdk 10` sets the runtime floor, but it does NOT guarantee the newest Android build tools can emit an APK that installs on every old device.
- Test the produced APK on the Galaxy Y. If installation fails due to manifest/build compatibility, use an older compatible Android build toolchain.
- This app has not been compiled or device-tested in this environment.

## Next development steps
1. Configure a catalog endpoint.
2. Add a background thread for network loading (the first prototype intentionally keeps the UI minimal; network loading should be moved off the UI thread before release).
3. Add thumbnail caching and paging.
4. Test playback, memory use, and network behavior on the actual device.


## TikTok Legacy Gateway configuration (v0.1 update)
The app now requests:
`https://tiktok-legacy-gateway.onrender.com/api/videos`

It understands the gateway response format:
`{"videos":[{"title":"Big Buck Bunny (360p)","url":"/video/bunny-360"}]}`

Relative video paths are resolved against the gateway host, so `/video/bunny-360`
becomes `https://tiktok-legacy-gateway.onrender.com/video/bunny-360`.
The catalog is loaded on a background thread, not on the Android UI thread.

The launcher icon and in-app header logo are included under
`app/src/main/res/drawable-nodpi/`. This is still a source project ZIP, not an APK.
Build and test it on the target phone; Android 4.1.2/ARMv7 compatibility has not
been verified by a device test in this environment. Although the project has
`minSdk 10` and no native `.so` libraries, ARMv6 support still depends on the
Android build toolchain and runtime testing.
