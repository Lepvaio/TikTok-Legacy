package com.legacy.tiktok;

public class VideoItem {
    public String title;
    public String url;

    public VideoItem(String title, String url) {
        this.title = title;
        this.url = url;
    }
}
