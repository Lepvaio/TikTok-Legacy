package com.legacy.tiktok;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;

/**
 * TikTok Legacy 0.1 - ARMv6-first starter with Gateway video catalog.
 * Network work is done off the UI thread for old Android devices.
 */
public class MainActivity extends Activity {
    private ArrayList<VideoItem> videos = new ArrayList<VideoItem>();
    private LinearLayout layout;
    private ListView list;
    private TextView status;

    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setBackgroundDrawableResource(android.R.color.black);

        layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(0xff101010);

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.HORIZONTAL);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        brand.setPadding(14, 10, 14, 4);

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.legacy.tiktok.R.drawable.logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        brand.addView(logo, new LinearLayout.LayoutParams(58, 58));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(12, 0, 0, 0);

        TextView header = new TextView(this);
        header.setText("TikTok Legacy");
        header.setTextColor(0xffffffff);
        header.setTextSize(22);
        titles.addView(header);

        TextView subtitle = new TextView(this);
        subtitle.setText("ARMv6 Edition  •  v0.1");
        subtitle.setTextColor(0xffaaaaaa);
        subtitle.setTextSize(12);
        titles.addView(subtitle);
        brand.addView(titles, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        layout.addView(brand);

        status = new TextView(this);
        status.setText("Dang tai video...");
        status.setTextColor(0xffcccccc);
        status.setTextSize(14);
        status.setGravity(Gravity.CENTER);
        status.setPadding(12, 18, 12, 18);
        layout.addView(status);

        list = new ListView(this);
        list.setBackgroundColor(0xff181818);
        list.setCacheColorHint(0xff181818);
        list.setVisibility(View.GONE);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                VideoItem item = videos.get(position);
                PlayerActivity.open(MainActivity.this, item.title, item.url);
            }
        });
        layout.addView(list, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        setContentView(layout);
        new LoadVideosTask().execute();
    }

    private class LoadVideosTask extends AsyncTask<Void, Void, ArrayList<VideoItem>> {
        protected ArrayList<VideoItem> doInBackground(Void... params) {
            return Catalog.load(MainActivity.this);
        }

        protected void onPostExecute(ArrayList<VideoItem> loaded) {
            videos = loaded;
            if (videos.size() == 0) {
                status.setText("Chua tai duoc video. Kiem tra ket noi Internet va thu lai.");
                return;
            }

            ArrayList<String> titles = new ArrayList<String>();
            for (int i = 0; i < videos.size(); i++) {
                titles.add(videos.get(i).title);
            }
            list.setAdapter(new ArrayAdapter<String>(
                MainActivity.this, android.R.layout.simple_list_item_1, titles));
            status.setText("Da tai " + videos.size() + " video");
            list.setVisibility(View.VISIBLE);
        }
    }
}
