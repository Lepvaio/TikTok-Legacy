package com.legacy.tiktok;

import android.content.Context;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Loads the video list from TikTok Legacy Gateway.
 * Gateway response:
 * {"videos":[{"title":"...","url":"/video/bunny-360"}]}
 */
public class Catalog {
    public static final String CATALOG_URL =
        "https://tiktok-legacy-gateway.onrender.com/api/videos";

    public static ArrayList<VideoItem> load(Context context) {
        ArrayList<VideoItem> result = new ArrayList<VideoItem>();
        HttpURLConnection connection = null;
        BufferedReader reader = null;
        try {
            URL catalogUrl = new URL(CATALOG_URL);
            connection = (HttpURLConnection) catalogUrl.openConnection();
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(20000);
            connection.setRequestMethod("GET");
            connection.setUseCaches(false);
            connection.setRequestProperty("Accept", "application/json");

            reader = new BufferedReader(new InputStreamReader(
                connection.getInputStream(), "UTF-8"));
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) body.append(line);

            String json = body.toString();
            JSONArray array;
            if (json.trim().startsWith("[")) {
                array = new JSONArray(json);
            } else {
                JSONObject root = new JSONObject(json);
                array = root.optJSONArray("videos");
                if (array == null) array = new JSONArray();
            }

            for (int i = 0; i < array.length(); i++) {
                JSONObject object = array.optJSONObject(i);
                if (object == null) continue;
                String title = object.optString("title", "Video");
                String path = object.optString("url", "");
                if (path.length() == 0) continue;

                // Gateway sends /video/... paths. Resolve them against its HTTPS host.
                URL resolved = new URL(catalogUrl, path);
                String videoUrl = resolved.toString();
                if (videoUrl.startsWith("https://") || videoUrl.startsWith("http://")) {
                    result.add(new VideoItem(title, videoUrl));
                }
            }
        } catch (Exception ignored) {
            // MainActivity shows a readable empty/error state.
        } finally {
            try { if (reader != null) reader.close(); } catch (Exception ignored) {}
            if (connection != null) connection.disconnect();
        }
        return result;
    }
}
