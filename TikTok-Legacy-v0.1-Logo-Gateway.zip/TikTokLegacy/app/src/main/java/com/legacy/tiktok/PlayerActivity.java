package com.legacy.tiktok;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.MediaController;
import android.widget.Toast;

public class PlayerActivity extends Activity {
    private VideoView video;

    public static void open(Context context, String title, String url) {
        Intent intent = new Intent(context, PlayerActivity.class);
        intent.putExtra("title", title);
        intent.putExtra("url", url);
        context.startActivity(intent);
    }

    public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(1);
        getWindow().setBackgroundDrawableResource(android.R.color.black);

        String title = getIntent().getStringExtra("title");
        String url = getIntent().getStringExtra("url");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(0xff000000);

        TextView heading = new TextView(this);
        heading.setText(title == null ? "Video" : title);
        heading.setTextColor(0xffffffff);
        heading.setTextSize(16);
        heading.setPadding(12, 12, 12, 12);
        layout.addView(heading);

        video = new VideoView(this);
        video.setMediaController(new MediaController(this));
        layout.addView(video, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        TextView note = new TextView(this);
        note.setText("Neu video khong phat, dinh dang/codec co the khong duoc Android 2.3 ho tro.");
        note.setTextColor(0xffaaaaaa);
        note.setTextSize(11);
        note.setGravity(Gravity.CENTER);
        note.setPadding(8, 8, 8, 8);
        layout.addView(note);

        setContentView(layout);

        if (url != null && url.length() > 0) {
            video.setVideoPath(url);
            video.setOnErrorListener(new android.media.MediaPlayer.OnErrorListener() {
                public boolean onError(android.media.MediaPlayer mp, int what, int extra) {
                    Toast.makeText(PlayerActivity.this,
                        "Khong the phat video nay tren thiet bi.", Toast.LENGTH_LONG).show();
                    return true;
                }
            });
            video.start();
        }
    }

    protected void onPause() {
        super.onPause();
        if (video != null && video.isPlaying()) video.pause();
    }

    protected void onDestroy() {
        if (video != null) video.stopPlayback();
        super.onDestroy();
    }
}
