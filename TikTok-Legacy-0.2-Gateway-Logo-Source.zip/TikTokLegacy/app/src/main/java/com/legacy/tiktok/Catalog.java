package com.legacy.tiktok;

import android.content.Context;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

/** Loads the public video list from the TikTok Legacy Gateway. */
public class Catalog {
    public static final String GATEWAY = "https://tiktok-legacy-gateway.onrender.com";
    public static final String CATALOG_URL = GATEWAY + "/api/videos";

    public static ArrayList<VideoItem> load(Context context) {
        ArrayList<VideoItem> result = new ArrayList<VideoItem>();
        HttpURLConnection connection = null;
        BufferedReader reader = null;
        try {
            connection = (HttpURLConnection) new URL(CATALOG_URL).openConnection();
            connection.setConnectTimeout(20000);
            connection.setReadTimeout(20000);
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/json");
            int status = connection.getResponseCode();
            if (status != HttpURLConnection.HTTP_OK) return result;
            reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) body.append(line);

            JSONObject root = new JSONObject(body.toString());
            JSONArray videos = root.optJSONArray("videos");
            if (videos == null) return result;
            for (int i = 0; i < videos.length(); i++) {
                JSONObject object = videos.optJSONObject(i);
                if (object == null) continue;
                String title = object.optString("title", "Video");
                String path = object.optString("url", "");
                String videoUrl = path.startsWith("http://") || path.startsWith("https://")
                    ? path : (path.startsWith("/") ? GATEWAY + path : GATEWAY + "/" + path);
                if (videoUrl.startsWith("https://") || videoUrl.startsWith("http://")) {
                    result.add(new VideoItem(title, videoUrl));
                }
            }
        } catch (Exception ignored) {
            // The screen displays a friendly offline message if the gateway is unavailable.
        } finally {
            try { if (reader != null) reader.close(); } catch (Exception ignored) { }
            if (connection != null) connection.disconnect();
        }
        return result;
    }
}
