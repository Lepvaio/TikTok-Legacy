package com.legacy.tiktok;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;

/** TikTok Legacy 0.2 - loads its video catalog from the configured gateway. */
public class MainActivity extends Activity {
    private ArrayList<VideoItem> videos = new ArrayList<VideoItem>();
    private LinearLayout layout;
    private ListView list;
    private TextView message;

    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setBackgroundDrawableResource(android.R.color.black);
        buildScreen();
        loadVideos();
    }

    private void buildScreen() {
        layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(0xff101010);

        TextView header = new TextView(this);
        header.setText("TikTok Legacy");
        header.setTextColor(0xffffffff);
        header.setTextSize(23);
        header.setPadding(14, 12, 14, 8);
        layout.addView(header);

        TextView subtitle = new TextView(this);
        subtitle.setText("LEGACY VIDEO FEED  •  v0.2");
        subtitle.setTextColor(0xffaaaaaa);
        subtitle.setTextSize(12);
        subtitle.setPadding(14, 0, 14, 12);
        layout.addView(subtitle);

        message = new TextView(this);
        message.setText("Dang tai danh sach video...");
        message.setTextColor(0xffcccccc);
        message.setTextSize(16);
        message.setGravity(Gravity.CENTER);
        message.setPadding(20, 30, 20, 30);
        layout.addView(message, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        list = new ListView(this);
        list.setBackgroundColor(0xff181818);
        list.setCacheColorHint(0xff181818);
        list.setVisibility(View.GONE);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                VideoItem item = videos.get(position);
                PlayerActivity.open(MainActivity.this, item.title, item.url);
            }
        });
        layout.addView(list, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(layout);
    }

    private void loadVideos() {
        new AsyncTask<Void, Void, ArrayList<VideoItem>>() {
            protected ArrayList<VideoItem> doInBackground(Void... unused) {
                return Catalog.load(MainActivity.this);
            }
            protected void onPostExecute(ArrayList<VideoItem> loaded) {
                videos = loaded;
                if (videos.size() == 0) {
                    message.setText("Chua tai duoc video. Kiem tra ket noi Internet hoac thu lai sau it phut.");
                    list.setVisibility(View.GONE);
                    message.setVisibility(View.VISIBLE);
                    return;
                }
                ArrayList<String> titles = new ArrayList<String>();
                for (int i = 0; i < videos.size(); i++) titles.add(videos.get(i).title);
                list.setAdapter(new ArrayAdapter<String>(MainActivity.this,
                    android.R.layout.simple_list_item_1, titles));
                message.setVisibility(View.GONE);
                list.setVisibility(View.VISIBLE);
            }
        }.execute();
    }
}
