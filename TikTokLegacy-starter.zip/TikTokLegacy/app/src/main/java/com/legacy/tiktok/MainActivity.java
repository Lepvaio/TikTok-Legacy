package com.legacy.tiktok;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.MediaController;
import android.widget.EditText;
import android.widget.Toast;

/**
 * TikTok Legacy starter viewer.
 * Android API 9 compatible Java source; actual codec/network support depends on device firmware.
 */
public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 41;
    private FrameLayout root;
    private VideoView video;
    private TextView title;
    private TextView hint;
    private float downY;
    private String currentSource = "";

    public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        buildUi();
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        video = new VideoView(this);
        FrameLayout.LayoutParams vp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT);
        root.addView(video, vp);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(14, 12, 14, 8);
        top.setBackgroundColor(0x66000000);

        title = new TextView(this);
        title.setText("TikTok Legacy");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER);
        top.addView(title, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 42));

        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP);
        root.addView(top, tp);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setPadding(12, 8, 12, 12);
        bottom.setBackgroundColor(0x99000000);

        hint = new TextView(this);
        hint.setText("Chưa có video. Thêm video từ máy hoặc URL trực tiếp.");
        hint.setTextColor(Color.WHITE);
        hint.setTextSize(14);
        hint.setGravity(Gravity.CENTER);
        bottom.addView(hint, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 44));

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER);
        Button local = makeButton("Video trong máy");
        Button url = makeButton("URL video");
        actions.addView(local, new LinearLayout.LayoutParams(0, 46, 1));
        actions.addView(url, new LinearLayout.LayoutParams(0, 46, 1));
        bottom.addView(actions);

        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        root.addView(bottom, bp);

        local.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { chooseLocalVideo(); }
        });
        url.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { askForUrl(); }
        });

        root.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    downY = e.getY();
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_UP) {
                    float delta = e.getY() - downY;
                    if (Math.abs(delta) > 90) {
                        Toast.makeText(MainActivity.this,
                                "Bản khởi đầu: thêm video bằng hai nút bên dưới.",
                                Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
                return true;
            }
        });

        setContentView(root);
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(13);
        return b;
    }

    private void chooseLocalVideo() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("video/*");
        try {
            startActivityForResult(Intent.createChooser(i, "Chọn video"), PICK_VIDEO);
        } catch (Exception ex) {
            Toast.makeText(this, "Không mở được trình chọn video trên máy này.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void askForUrl() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("https://.../video.mp4");
        new AlertDialog.Builder(this)
            .setTitle("Nguồn video trực tiếp")
            .setMessage("Nhập URL tệp video MP4 trực tiếp. Link trang TikTok không phải link MP4.")
            .setView(input)
            .setPositiveButton("Phát", new android.content.DialogInterface.OnClickListener() {
                public void onClick(android.content.DialogInterface d, int which) {
                    String s = input.getText().toString().trim();
                    if (s.length() > 0) play(Uri.parse(s));
                }
            })
            .setNegativeButton("Hủy", null)
            .show();
    }

    private void play(Uri uri) {
        currentSource = uri.toString();
        try {
            video.stopPlayback();
            video.setVideoURI(uri);
            video.setMediaController(new MediaController(this));
            video.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener() {
                public void onPrepared(android.media.MediaPlayer mp) {
                    mp.setLooping(true);
                    video.start();
                    hint.setText("Đang phát • Ưu tiên video H.264 360p");
                }
            });
            video.setOnErrorListener(new android.media.MediaPlayer.OnErrorListener() {
                public boolean onError(android.media.MediaPlayer mp, int what, int extra) {
                    hint.setText("Không phát được. Thử MP4 H.264 Baseline + AAC, 360p.");
                    return true;
                }
            });
            hint.setText("Đang tải video...");
        } catch (Exception ex) {
            hint.setText("Nguồn video không hợp lệ hoặc thiết bị không hỗ trợ.");
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) play(uri);
        }
    }

    protected void onPause() {
        super.onPause();
        if (video != null && video.isPlaying()) video.pause();
    }

    protected void onDestroy() {
        if (video != null) video.stopPlayback();
        super.onDestroy();
    }
}
