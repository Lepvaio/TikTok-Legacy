# TikTok Legacy Viewer — starter 0.1.0

A minimal native Android video-viewer shell designed around a low-dependency Java implementation.

## Current scope
- `minSdk 9` (Android 2.3 / Gingerbread)
- Java 7 source compatibility
- Local video selection
- Direct MP4 URL input
- Full-screen portrait playback using Android `VideoView` / platform `MediaPlayer`
- No backend and no third-party runtime libraries

## Important limitations
- This is a starter viewer, **not yet a TikTok feed client**.
- A TikTok watch-page URL is not a direct video URL. The URL field expects a directly playable media URL.
- TikTok does not provide an official public feed API for Android 2.3. Automatic TikTok feed discovery is therefore not implemented.
- H.264/AAC playback depends on each device's firmware and hardware decoder. The target profile is H.264 Baseline, 360p, AAC-LC.
- Android 2.3 devices have obsolete TLS/certificate stores. Modern HTTPS hosts may fail even if the video codec is supported.
- `minSdk 9` is a declared compatibility target, not a guarantee that every ARMv6 device will play every stream. Test on the actual handset.

## Build
1. Install Android Studio with Android SDK Platform 33 and JDK 11.
2. Open this folder as a Gradle project.
3. Let Gradle sync.
4. Build the `app` debug APK.

The project uses Android Gradle Plugin 7.4.2 / Gradle 7.5. It does not include the Gradle wrapper JAR.

## Next engineering steps
1. Build and install on a real ARMv6 Android 2.3 device.
2. Test local H.264 Baseline/AAC MP4 playback.
3. Add a lightweight playlist format (for example, a text/JSON list of direct media URLs).
4. Add swipe-to-next only after the playlist/source contract is defined.
5. Evaluate HTTPS compatibility separately from video decoding.
