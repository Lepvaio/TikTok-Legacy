package com.legacy.tiktok;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.MediaController;
import android.widget.Toast;

/**
 * TikTok Legacy 0.2.0
 * Lightweight public-demo-video feed using Android's built-in VideoView.
 * Actual network/TLS and codec compatibility depends on the Android device.
 */
public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 41;
    private FrameLayout root;
    private VideoView video;
    private TextView title;
    private TextView caption;
    private TextView status;
    private Button playButton;
    private float downY;
    private int index = 0;
    private boolean usingCustomVideo = false;

    // Public MP4 sample clips hosted by Google's public video sample bucket.
    // These are demonstration clips, not a live TikTok feed.
    private final String[][] feed = new String[][] {
        {"Big Buck Bunny sample", "Public MP4 demo • Google video samples",
         "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"},
        {"For Bigger Escapes", "Public MP4 demo • Google video samples",
         "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"},
        {"For Bigger Fun", "Public MP4 demo • Google video samples",
         "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4"},
        {"For Bigger Joyrides", "Public MP4 demo • Google video samples",
         "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4"},
        {"For Bigger Meltdowns", "Public MP4 demo • Google video samples",
         "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4"}
    };

    public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        buildUi();
        playFeedItem(0);
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        video = new VideoView(this);
        FrameLayout.LayoutParams vp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT);
        root.addView(video, vp);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(12, 8, 12, 8);
        top.setBackgroundColor(0x66000000);

        title = new TextView(this);
        title.setText("TikTok Legacy");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER);
        top.addView(title, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 40));

        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP);
        root.addView(top, tp);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setPadding(12, 8, 12, 10);
        bottom.setBackgroundColor(0x99000000);

        caption = new TextView(this);
        caption.setTextColor(Color.WHITE);
        caption.setTextSize(14);
        caption.setGravity(Gravity.CENTER_VERTICAL);
        bottom.addView(caption, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 42));

        status = new TextView(this);
        status.setTextColor(0xFFDDDDDD);
        status.setTextSize(11);
        status.setGravity(Gravity.CENTER);
        bottom.addView(status, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 25));

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER);
        Button previous = makeButton("Trước");
        playButton = makeButton("Tạm dừng");
        Button next = makeButton("Tiếp");
        Button local = makeButton("Video máy");
        Button url = makeButton("URL MP4");

        actions.addView(previous, new LinearLayout.LayoutParams(0, 44, 1));
        actions.addView(playButton, new LinearLayout.LayoutParams(0, 44, 1));
        actions.addView(next, new LinearLayout.LayoutParams(0, 44, 1));
        bottom.addView(actions);

        LinearLayout extra = new LinearLayout(this);
        extra.setGravity(Gravity.CENTER);
        extra.addView(local, new LinearLayout.LayoutParams(0, 42, 1));
        extra.addView(url, new LinearLayout.LayoutParams(0, 42, 1));
        bottom.addView(extra);

        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        root.addView(bottom, bp);

        previous.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { if (!usingCustomVideo) playFeedItem(index - 1); }
        });
        next.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { if (!usingCustomVideo) playFeedItem(index + 1); }
        });
        playButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { togglePlayback(); }
        });
        local.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { chooseLocalVideo(); }
        });
        url.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { askForUrl(); }
        });

        View.OnTouchListener swipe = new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    downY = e.getY();
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_UP) {
                    float delta = e.getY() - downY;
                    if (Math.abs(delta) > 70) {
                        if (delta < 0) {
                            if (!usingCustomVideo) playFeedItem(index + 1);
                        } else {
                            if (!usingCustomVideo) playFeedItem(index - 1);
                        }
                    }
                    return true;
                }
                return true;
            }
        };
        video.setOnTouchListener(swipe);
        root.setOnTouchListener(swipe);
        setContentView(root);
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(11);
        return b;
    }

    private void playFeedItem(int requestedIndex) {
        if (feed.length == 0) return;
        usingCustomVideo = false;
        index = requestedIndex;
        if (index < 0) index = feed.length - 1;
        if (index >= feed.length) index = 0;
        caption.setText(feed[index][0] + "\n" + feed[index][1]);
        play(Uri.parse(feed[index][2]));
    }

    private void togglePlayback() {
        if (video == null) return;
        if (video.isPlaying()) {
            video.pause();
            playButton.setText("Phát");
        } else {
            video.start();
            playButton.setText("Tạm dừng");
        }
    }

    private void chooseLocalVideo() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("video/*");
        try {
            startActivityForResult(Intent.createChooser(i, "Chọn video"), PICK_VIDEO);
        } catch (Exception ex) {
            Toast.makeText(this, "Không mở được trình chọn video trên máy này.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void askForUrl() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("https://.../video.mp4");
        new AlertDialog.Builder(this)
            .setTitle("Nguồn video trực tiếp")
            .setMessage("Nhập URL tệp MP4 trực tiếp. Link trang web/TikTok không phải link MP4.")
            .setView(input)
            .setPositiveButton("Phát", new android.content.DialogInterface.OnClickListener() {
                public void onClick(android.content.DialogInterface d, int which) {
                    String s = input.getText().toString().trim();
                    if (s.length() > 0) {
                        usingCustomVideo = true;
                        caption.setText("Video từ URL riêng");
                        play(Uri.parse(s));
                    }
                }
            })
            .setNegativeButton("Hủy", null)
            .show();
    }

    private void play(Uri uri) {
        try {
            video.stopPlayback();
            status.setText("Đang kết nối nguồn video...");
            playButton.setText("Tạm dừng");
            video.setVideoURI(uri);
            video.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener() {
                public void onPrepared(android.media.MediaPlayer mp) {
                    mp.setLooping(false);
                    video.start();
                    status.setText("Đang phát • Vuốt lên để xem tiếp");
                }
            });
            video.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener() {
                public void onCompletion(android.media.MediaPlayer mp) {
                    if (!usingCustomVideo) playFeedItem(index + 1);
                    else status.setText("Video đã kết thúc");
                }
            });
            video.setOnErrorListener(new android.media.MediaPlayer.OnErrorListener() {
                public boolean onError(android.media.MediaPlayer mp, int what, int extra) {
                    status.setText("Không phát được: thử mạng khác hoặc video MP4 H.264/AAC.");
                    Toast.makeText(MainActivity.this,
                            "Thiết bị có thể không hỗ trợ HTTPS/TLS hoặc codec video này.",
                            Toast.LENGTH_LONG).show();
                    return true;
                }
            });
        } catch (Exception ex) {
            status.setText("URL không hợp lệ hoặc thiết bị không hỗ trợ.");
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                usingCustomVideo = true;
                caption.setText("Video từ thiết bị");
                play(uri);
            }
        }
    }

    protected void onPause() {
        super.onPause();
        if (video != null && video.isPlaying()) video.pause();
    }

    protected void onDestroy() {
        if (video != null) video.stopPlayback();
        super.onDestroy();
    }
}
