# TikTok Legacy Internet Demo Feed 0.2.0

This update adds a swipeable demo feed using public MP4 sample clips hosted by Google's public video sample bucket.

## Features
- Swipe up/down or use Previous/Next to move through the demo playlist.
- Automatically starts the selected clip.
- Automatically advances to the next clip when playback completes.
- Pause/resume.
- Play a local video or enter a direct MP4 URL.
- minSdk 9 (Android 2.3), Java 7 source compatibility.

## Important limitations
- This is a **public demo-video playlist**, not a live TikTok feed and not a general-purpose video discovery service.
- The sample clips may be landscape and may be higher resolution than an ARMv6 device can decode.
- Android 2.3 devices have old TLS/certificate stores. HTTPS connections to modern servers may fail.
- Video codec support depends on device firmware. H.264 Baseline/AAC-LC at low resolution is the preferred target, but the included public samples are not guaranteed to match it.
- `minSdk 9` means the app can install on Android 2.3; it does not guarantee that every Internet stream will play on every handset.

## Build
Use the GitHub Actions workflow in `.github/workflows/android-build.yml`, or open this folder in Android Studio with JDK 17 and Android SDK Platform 33.
